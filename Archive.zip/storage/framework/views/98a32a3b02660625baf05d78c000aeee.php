<?php $__env->startSection('title','Users'); ?>

<?php $__env->startSection('content'); ?>
<div class="container py-5 px-md-4">

  
  <div class="row mb-5 justify-content-center">
    <div class="col-md-6">
      <div class="card shadow-lg rounded-3 border-0 overflow-hidden">

        <div class="card-body text-center pt-5">
          <h4 class="fw-bold mb-1"><?php echo e(auth()->user()->name); ?></h4>
          <p class="text-muted mb-3"><?php echo e(auth()->user()->email); ?></p>
          <div class="mb-3">
            <?php $__empty_1 = true; $__currentLoopData = auth()->user()->roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
              <span class="badge bg-primary me-1"><?php echo e(ucfirst($role->name)); ?></span>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
              <span class="text-secondary">No roles assigned</span>
            <?php endif; ?>
          </div>
          <a href="<?php echo e(route('users.show', auth()->user())); ?>"
             class="btn btn-outline-secondary btn-sm me-2">
            <i class="bi bi-eye me-1"></i>View Profile
          </a>
          <a href="<?php echo e(route('users.edit', auth()->user())); ?>"
             class="btn btn-outline-primary btn-sm me-2">
            <i class="bi bi-pencil me-1"></i>Edit Profile
          </a>
          <a href="<?php echo e(route('logout')); ?>" 
             onclick="event.preventDefault();document.getElementById('logout-form').submit();"
             class="btn btn-outline-danger btn-sm">
            <i class="bi bi-box-arrow-right me-1"></i>Logout
          </a>
          <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
            <?php echo csrf_field(); ?>
          </form>
        </div>
      </div>
    </div>
  </div>

  
  <div class="d-flex justify-content-between align-items-center mb-4">
    <div class="page-header d-flex align-items-center mb-0">
      <i class="bi bi-people-fill me-2 fs-3" style="color: #e2ae76;"></i>
      <h2 class="mb-0 fw-bold" style="color: #041930;">Users</h2>
    </div>
    <a href="<?php echo e(route('users.create')); ?>" class="btn btn-gold-blue btn-lg">
      <i class="bi bi-plus-lg me-1"></i> Add User
    </a>
  </div>

  
  <?php if(session('success')): ?>
    <div class="alert alert-success mb-4 p-3 rounded-3 shadow-sm">
      <i class="bi bi-check-circle-fill me-2"></i>
      <strong>Success!</strong> <?php echo e(session('success')); ?>

    </div>
  <?php endif; ?>

  
  <div class="table-responsive">
    <table class="table table-hover table-bordered shadow-sm rounded">
      <thead style="background-color: #e2ae76; color: #041930;">
        <tr class="text-center fw-semibold">
          <th>Name</th>
          <th>Email</th>
          <th>Roles</th>
          <th>Status</th>
          <th class="text-end">Actions</th>
        </tr>
      </thead>
      <tbody>
        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $u): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <tr>
            <td><?php echo e($u->name); ?></td>
            <td><?php echo e($u->email); ?></td>
            <td>
              <?php $__empty_1 = true; $__currentLoopData = $u->roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <span class="badge bg-secondary"><?php echo e(ucfirst($r->name)); ?></span>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <em class="text-muted">—</em>
              <?php endif; ?>
            </td>
            <td class="text-center">
              <span class="badge <?php echo e($u->status ? 'bg-success' : 'bg-danger'); ?>">
                <?php echo e($u->status ? 'Active' : 'Inactive'); ?>

              </span>
            </td>
            <td class="text-end">
              <a href="<?php echo e(route('users.show', $u)); ?>" class="btn btn-sm btn-deepblue me-1">
                <i class="bi bi-eye"></i> View
              </a>
              <a href="<?php echo e(route('users.edit', $u)); ?>" class="btn btn-sm btn-gold me-1">
                <i class="bi bi-pencil"></i> Edit
              </a>
              <?php if(auth()->user()->hasRole('super') && auth()->id() !== $u->id): ?>
                <form action="<?php echo e(route('users.toggleStatus', $u->id)); ?>" method="POST" class="d-inline">
                  <?php echo csrf_field(); ?> <?php echo method_field('PATCH'); ?>
                  <button type="submit" class="btn btn-sm <?php echo e($u->status ? 'btn-red' : 'btn-deepblue'); ?> me-1">
                    <?php echo e($u->status ? 'Deactivate' : 'Activate'); ?>

                  </button>
                </form>
              <?php endif; ?>
              <form action="<?php echo e(route('users.destroy', $u)); ?>" method="POST" class="d-inline" onsubmit="return confirm('Delete this user?');">
                <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                <button class="btn btn-sm btn-red"><i class="bi bi-trash"></i> Delete</button>
              </form>
            </td>
          </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </tbody>
    </table>
  </div>

  
  <div class="mt-4">
    <?php echo e($users->links()); ?>

  </div>
</div>


<style>
  .bg-gradient {
    background: linear-gradient(135deg, #041930 0%, #e2ae76 100%);
  }
  .avatar-wrapper {
    width: 120px; height: 120px;
    overflow: hidden; border-radius: 50%;
    box-shadow: 0 0 15px rgba(0,0,0,0.2);
  }
  .btn-gold-blue {
    background-color: #e2ae76 !important;
    color: #041930 !important;
    border: 1px solid #e2ae76;
  }
  .btn-gold-blue:hover { background-color: #d89d5c !important; color: #fff !important; }
  .btn-gold {
    border: 1px solid #e2ae76 !important;
    color: #e2ae76 !important;
    background-color: transparent !important;
  }
  .btn-gold:hover { background-color: #e2ae76 !important; color: #fff !important; }
  .btn-deepblue {
    border: 1px solid #041930 !important;
    color: #041930 !important;
    background-color: transparent !important;
  }
  .btn-deepblue:hover { background-color: #041930 !important; color: #fff !important; }
  .btn-red {
    border: 1px solid red !important;
    color: red !important;
    background-color: transparent !important;
  }
  .btn-red:hover { background-color: red !important; color: #fff !important; }
</style>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Applications/XAMPP/htdocs/bakery/resources/views/frontend/user-management/users/index.blade.php ENDPATH**/ ?>