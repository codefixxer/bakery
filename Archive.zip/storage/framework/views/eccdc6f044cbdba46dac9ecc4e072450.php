<?php $__env->startSection('title', 'Notifications'); ?>

<?php $__env->startSection('content'); ?>
<div class="container py-5">
    <h4 class="mb-4">Notifications</h4>

    <?php $__currentLoopData = $notifications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $notification): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="alert alert-info">
        <strong><?php echo e($notification->title); ?></strong>
        <p><?php echo e($notification->message); ?></p>
        <p class="text-muted"><?php echo e($notification->created_at->diffForHumans()); ?></p>

        <!-- Mark as Read Button -->
        <form action="<?php echo e(route('notifications.markAsRead', $notification->id)); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <?php echo method_field('POST'); ?>  <!-- This tells Laravel it's a POST request -->
            <button type="submit" class="btn btn-sm btn-primary">Mark as Read</button>
        </form>
    </div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


  
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Applications/XAMPP/htdocs/bakery/resources/views/frontend/notifications/index.blade.php ENDPATH**/ ?>