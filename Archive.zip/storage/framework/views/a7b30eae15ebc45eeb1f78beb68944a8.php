<?php $__env->startSection('title', isset($externalSupply) ? 'Edit External Supply' : 'Create External Supply'); ?>

<?php $__env->startSection('content'); ?>
<div class="container py-5">
  <div class="card border-primary shadow-sm">
    <div class="card-header d-flex align-items-center gap-2" style="background-color: #041930; color: #e2ae76;">
      <iconify-icon icon="mdi:truck-delivery" class="menu-icon" style="color: #e2ae76; font-size:35px"></iconify-icon>
      <h5 class="mb-0" style="color: #e2ae76;">
        <?php echo e(isset($externalSupply) ? 'Edit External Supply' : 'Create External Supply'); ?>

      </h5>
    </div>

    <div class="card-body">
      <form method="POST"
            action="<?php echo e(isset($externalSupply)
                       ? route('external-supplies.update', $externalSupply->id)
                       : route('external-supplies.store')); ?>"
            class="row g-3 needs-validation"
            novalidate>
        <?php echo csrf_field(); ?>
        <?php if(isset($externalSupply)): ?>
          <?php echo method_field('PUT'); ?>
        <?php endif; ?>

        <!-- Supply Name -->
        <div class="col-md-6">
          <label for="supply_name" class="form-label fw-semibold">Supply Name</label>
          <input
            type="text"
            id="supply_name"
            name="supply_name"
            class="form-control form-control-lg"
            required
            value="<?php echo e(old('supply_name', $externalSupply->supply_name ?? '')); ?>">
          <div class="invalid-feedback">Please enter a supply name.</div>
        </div>

        <!-- Client -->
        <div class="col-md-6">
          <label for="client_id" class="form-label fw-semibold">Client</label>
          <select id="client_id" name="client_id" class="form-select form-control-lg" required>
            <option value="">Select Client</option>
            <?php $__currentLoopData = $clients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $client): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <option
                value="<?php echo e($client->id); ?>"
                <?php echo e(old('client_id', $externalSupply->client_id ?? '') == $client->id ? 'selected' : ''); ?>>
                <?php echo e($client->name); ?>

              </option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </select>
        </div>

        <!-- Supply Date -->
        <div class="col-md-6">
          <label for="supply_date" class="form-label fw-semibold">Supply Date</label>
          <input
            type="date"
            id="supply_date"
            name="supply_date"
            class="form-control form-control-lg"
            required
            value="<?php echo e(old('supply_date', isset($externalSupply) ? $externalSupply->supply_date->format('Y-m-d') : '')); ?>">
        </div>

        <!-- Template Selection (only on create) -->
        <?php if(!isset($externalSupply)): ?>
        <div class="col-md-6">
          <label for="template_select" class="form-label fw-semibold">Choose Template</label>
          <select id="template_select" name="template_id" class="form-select form-control-lg">
            <option value="">-- Select Template --</option>
            <?php $__currentLoopData = $templates; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $name): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <option value="<?php echo e($id); ?>"><?php echo e($name); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </select>
        </div>
        <?php endif; ?>

        <!-- Save As -->
        <div class="col-md-6">
          <label for="template_action" class="form-label fw-semibold">Save As</label>
          <?php
            $default = old('template_action',
              isset($externalSupply)
                ? ($externalSupply->save_template ? 'template' : 'none')
                : 'none');
          ?>
          <select id="template_action" name="template_action" class="form-select form-control-lg">
            <option value="none"     <?php echo e($default=='none'     ? 'selected' : ''); ?>>Just Save</option>
            <option value="template" <?php echo e($default=='template' ? 'selected' : ''); ?>>Save as Template</option>
            <option value="both"     <?php echo e($default=='both'     ? 'selected' : ''); ?>>Save & Template</option>
          </select>
        </div>

        <!-- Supplied Products -->
        <div class="col-12">
          <div class="card border-primary shadow-sm">
            <div class="card-header d-flex align-items-center" style="background-color: #041930;">
              <strong style="color: #e2ae76; font-size: 1.1rem;">Supplied Products</strong>
            </div>
            
            <div class="card-body p-0">
              <div class="table-responsive">
                <table class="table table-hover align-middle mb-0" id="supplyTable">
                  <thead class="table-light">
                    <tr>
                      <th style="width: 40%;">Recipe</th>
                      <th style="width: 150px;">Price (€)</th>
                      <th style="width: 80px;">Qty</th>
                      <th style="width: 120px;">Total (€)</th>
                      <th style="width: 60px;">Action</th>
                    </tr>
                  </thead>
                  <tbody id="supplyTableBody">
                    <?php $__currentLoopData = old('recipes', $externalSupply->recipes ?? [null]); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <tr class="supply-row">
                        <td>
                          <select name="recipes[<?php echo e($index); ?>][id]" class="form-select recipe-select" required>
                            <option value="">Select Recipe</option>
                            <?php $__currentLoopData = $recipes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rec): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                              <option value="<?php echo e($rec->id); ?>"
                                      data-price="<?php echo e($rec->sell_mode==='kg' ? $rec->selling_price_per_kg : $rec->selling_price_per_piece); ?>"
                                      data-sell-mode="<?php echo e($rec->sell_mode); ?>"
                                      <?php echo e(old("recipes.$index.id", $item->recipe_id ?? '') == $rec->id ? 'selected' : ''); ?>>
                                <?php echo e($rec->recipe_name); ?>

                              </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                          </select>
                        </td>
                        <td>
                          <div class="input-group input-group-sm">
                            <span class="input-group-text">€</span>
                            <input type="text"
                                   name="recipes[<?php echo e($index); ?>][price]"
                                   class="form-control text-end price-field"
                                   readonly
                                   value="<?php echo e(old("recipes.$index.price", $item->price ?? '')); ?>">
                            <span class="input-group-text unit-field">/piece</span>
                          </div>
                        </td>
                        <td>
                          <input type="number"
                                 name="recipes[<?php echo e($index); ?>][qty]"
                                 class="form-control text-center qty-field"
                                 required
                                 value="<?php echo e(old("recipes.$index.qty", $item->qty ?? 0)); ?>">
                        </td>
                        <td>
                          <input type="text"
                                 name="recipes[<?php echo e($index); ?>][total_amount]"
                                 class="form-control total-field"
                                 readonly
                                 value="<?php echo e(old("recipes.$index.total_amount", $item->total_amount ?? '')); ?>">
                        </td>
                        <td class="text-center">
                          <button type="button" class="btn btn-outline-danger btn-sm remove-row">
                            <i class="bi bi-trash"></i>
                          </button>
                        </td>
                      </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </tbody>
                  
                </table>
              </div>
              <div class="p-3 border-top text-end">
                <button type="button" id="addRowBtn"
                class="btn btn-sm"
                style="border: 1px solid #e2ae76; color: #041930; background-color: transparent;"
                onmouseover="this.style.backgroundColor='#e2ae76'; this.style.color='white'; this.querySelector('i').style.color='white';"
                onmouseout="this.style.backgroundColor='transparent'; this.style.color='#041930'; this.querySelector('i').style.color='#041930';">
          <i class="bi bi-plus-circle me-1" style="color: #041930;"></i>
          Add Recipe
        </button>
        
              </div>
            </div>
          </div>
        </div>

        <!-- Total Amount -->
        <div class="col-md-6">
          <label class="form-label fw-semibold">Total Amount (€)</label>
          <input type="text" id="totalAmount" name="total_amount" class="form-control" readonly
                 value="<?php echo e(old('total_amount', $externalSupply->total_amount ?? '')); ?>">
        </div>

        <!-- Submit Button -->
        <div class="col-12 text-end mt-4">
          <button type="submit" class="btn btn-lg" style="background-color: #e2ae76; color: #041930;">
            <i class="bi bi-save2 me-2" style="color: #041930;"></i>
            <?php echo e(isset($externalSupply) ? 'Update External Supply' : 'Save External Supply'); ?>

          </button>
        </div>

      </form>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('scripts'); ?>
<script>
document.addEventListener('DOMContentLoaded', () => {
  const actionSelect = document.getElementById('template_action');
  const nameInput    = document.getElementById('supply_name');
  const nameLabel    = document.getElementById('supplyNameLabel');
  const supplyBody   = document.getElementById('supplyTableBody');
  const addBtn       = document.getElementById('addRowBtn');
  const dateInput    = document.getElementById('supply_date');
  const templateSelect = document.getElementById('template_select');
  const totalAmountInput = document.getElementById('totalAmount');

  function toggleNameRequirement() {
    const v = actionSelect.value;
    const isTemplate = v === 'template' || v === 'both';
    nameInput.required = isTemplate;
    if (nameLabel) nameLabel.textContent = isTemplate ? 'Template Name *' : 'Supply Name';
  }

  toggleNameRequirement();
  actionSelect?.addEventListener('change', toggleNameRequirement);

  // Clone a blank row (template)
  let rowIndex = supplyBody.querySelectorAll('.supply-row').length;
  const baseRow = supplyBody.querySelector('.supply-row');
  const blankRow = () => {
    const clone = baseRow.cloneNode(true);
    clone.querySelectorAll('input, select').forEach(el => {
      if (el.tagName === 'SELECT') el.selectedIndex = 0;
      else if (el.type === 'number') el.value = 0;
      else el.value = '';
    });
    return clone;
  };

  // Add row logic
  addBtn.addEventListener('click', () => {
    const newRow = blankRow();
    newRow.querySelectorAll('input, select').forEach(el => {
      if (el.name) el.name = el.name.replace(/\[\d+\]/, `[${rowIndex}]`);
    });
    supplyBody.appendChild(newRow);
    recalcRow(newRow);
    rowIndex++;
  });

  // Recalculate a row’s total
  function recalcRow(row) {
    const opt      = row.querySelector('.recipe-select')?.selectedOptions[0];
    const priceIn  = row.querySelector('input[name*="[price]"]');
    const unitSpan = row.querySelector('.unit-field');
    const qtyIn    = row.querySelector('input[name*="[qty]"]');
    const totalIn  = row.querySelector('input[name*="[total_amount]"]');

    const price = parseFloat(opt?.dataset.price || 0).toFixed(2);
    const mode  = opt?.dataset.sellMode || 'piece';

    if (priceIn) priceIn.value = price;
    if (unitSpan) unitSpan.textContent = mode === 'kg' ? '/kg' : '/piece';

    const qty = parseFloat(qtyIn?.value || 0);
    if (totalIn) totalIn.value = (price * qty).toFixed(2);

    calcSummary();
  }

  // Recalculate total amount
  function calcSummary() {
    let sum = 0;
    document.querySelectorAll('.total-field').forEach(input => {
      const val = parseFloat(input.value);
      if (!isNaN(val)) sum += val;
    });
    totalAmountInput.value = sum.toFixed(2);
  }

  // Event listeners for live updates
  supplyBody.addEventListener('change', e => {
    if (e.target.classList.contains('recipe-select')) {
      recalcRow(e.target.closest('tr'));
    }
  });

  supplyBody.addEventListener('input', e => {
    if (e.target.classList.contains('qty-field')) {
      recalcRow(e.target.closest('tr'));
    }
  });

  supplyBody.addEventListener('click', e => {
    if (e.target.closest('.remove-row') &&
        supplyBody.querySelectorAll('.supply-row').length > 1) {
      e.target.closest('tr').remove();
      calcSummary();
    }
  });

  // Init existing rows
  supplyBody.querySelectorAll('.supply-row').forEach(r => recalcRow(r));

  // Load from template
  templateSelect?.addEventListener('change', function() {
    const id = this.value;
    if (!id) return;

    fetch(`/external-supplies/template/${id}`)
      .then(res => res.json())
      .then(data => {
        document.getElementById('supply_name').value = data.supply_name;
        dateInput.value = data.supply_date;
        actionSelect.value = data.template_action;
        toggleNameRequirement();

        supplyBody.innerHTML = '';
        rowIndex = 0;

        data.rows.forEach(rowData => {
          const r = blankRow();
          r.querySelectorAll('input, select').forEach(el => {
            if (el.name) el.name = el.name.replace(/\[\d+\]/, `[${rowIndex}]`);
          });

          r.querySelector('.recipe-select').value = rowData.recipe_id;
          r.querySelector('input[name*="[qty]"]').value = rowData.qty;
          r.querySelector('input[name*="[total_amount]"]').value = parseFloat(rowData.total_amount).toFixed(2);

          supplyBody.appendChild(r);
          recalcRow(r);
          rowIndex++;
        });
      })
      .catch(console.error);
  });
});
</script>
<?php $__env->stopSection(); ?>




<?php echo $__env->make('frontend.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Applications/XAMPP/htdocs/bakery/resources/views/frontend/external-supplies/create.blade.php ENDPATH**/ ?>