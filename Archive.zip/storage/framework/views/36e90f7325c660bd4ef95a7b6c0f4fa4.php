<?php $__env->startSection('title','Return Goods'); ?>

<?php $__env->startSection('content'); ?>
<div class="container py-5 px-md-5">

  <!-- Header -->
  <div class="card border-primary shadow-sm mb-4">
    <div class="card-header d-flex align-items-center" style="background-color: #041930;">
      <i class="bi bi-arrow-counterclockwise me-2 fs-4" style="color: #e2ae76;"></i>
      <h5 class="mb-0" style="color: #e2ae76;">
        Return for <?php echo e($externalSupply->client->name); ?> — <?php echo e($externalSupply->supply_name); ?>

        <small class="d-block text-muted" style="font-size: 0.8rem;">Supply Date: <?php echo e($externalSupply->supply_date->format('Y-m-d')); ?></small>
      </h5>
    </div>

    <div class="card-body">
      <form method="POST" action="<?php echo e(route('returned-goods.store')); ?>">
        <?php echo csrf_field(); ?>
        <input type="hidden" name="client_id" value="<?php echo e($externalSupply->client->id); ?>">
        <input type="hidden" name="external_supply_id" value="<?php echo e($externalSupply->id); ?>">

        <!-- Return Date -->
        <div class="row mb-4">
          <div class="col-md-4">
            <label for="return_date" class="form-label fw-semibold">Return Date</label>
            <input
              type="date"
              id="return_date"
              name="return_date"
              class="form-control form-control-lg"
              value="<?php echo e(old('return_date', now()->format('Y-m-d'))); ?>"
              required>
          </div>
        </div>

        <!-- Return Table -->
        <div class="card-body px-4">
          <div class="table-responsive p-3">
            <table
              id="returnTable"
              class="table table-bordered table-striped table-hover align-middle mb-0 text-center"
              data-page-length="10"
            >
              <thead>
                <tr class="text-center">
                  <th class="text-center">Recipe</th>
                  <th class="text-center">Original Qty</th>
                  <th class="text-center">Returned So Far</th>
                  <th class="text-center">Remaining</th>
                  <th class="text-center">Qty to Return</th>
                  <th class="text-center">Unit Price (€)</th>
                  <th class="text-center">Line Total (€)</th>
                </tr>
              </thead>
              <tbody>
                <?php $__currentLoopData = $externalSupply->recipes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $line): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <?php
                    $returnedQty = $line->returns->sum('qty');
                    $remaining = $line->qty - $returnedQty;
                  ?>
                  <tr>
                    <td><?php echo e($line->recipe->recipe_name); ?></td>
                    <td><?php echo e($line->qty); ?></td>
                    <td><?php echo e($returnedQty); ?></td>
                    <td><?php echo e($remaining); ?></td>
                    <td>
                      <input 
                        type="number"
                        name="recipes[<?php echo e($line->id); ?>][qty]"
                        class="form-control form-control-sm return-qty text-center"
                        min="0"
                        max="<?php echo e($remaining); ?>"
                        value="<?php echo e(old("recipes.{$line->id}.qty", 0)); ?>">
                    </td>
                    <td>€<?php echo e(number_format($line->price, 2)); ?></td>
                    <td>
                      <input 
                        type="text"
                        name="recipes[<?php echo e($line->id); ?>][total_amount]"
                        class="form-control form-control-sm total-return text-end"
                        value="0.00"
                        readonly>
                    </td>
                  </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </tbody>
            </table>
          </div>
        </div>
        

        <!-- Submit Button -->
        <div class="text-end">
          <button class="btn btn-lg fw-semibold" style="background-color: #e2ae76; color: #041930;">
            <i class="bi bi-arrow-counterclockwise me-2" style="color: #041930;"></i>
            Submit Return
          </button>
        </div>
      </form>
    </div>
  </div>

</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('styles'); ?>
<!-- DataTables CSS -->
<link href="https://cdn.datatables.net/1.13.6/css/jquery.dataTables.min.css" rel="stylesheet">
<style>
  /* Match table heading with ingredients style */
  table#returnTable thead th {
    background-color: #e2ae76 !important;
    color: #041930 !important;
    text-align: center;
    vertical-align: middle;
    font-weight: 600;
  }

  table#returnTable td {
    text-align: center;
    vertical-align: middle;
  }

  /* DataTables sorting arrow override */
  table.dataTable thead .sorting:after,
  table.dataTable thead .sorting_asc:after,
  table.dataTable thead .sorting_desc:after {
    color: #041930 !important;
  }

  .dataTables_length select {
    appearance: none;
    background: #fff url('data:image/svg+xml;utf8,<svg fill="%23041930" height="20" viewBox="0 0 24 24" width="20" xmlns="http://www.w3.org/2000/svg"><path d="M7 10l5 5 5-5z"/></svg>') no-repeat right 10px center;
    padding-right: 30px;
    border: 1px solid #e2ae76;
    color: #041930;
    font-weight: 500;
    border-radius: 4px;
  }

  .dataTables_wrapper .dataTables_filter input {
    border-radius: 5px;
    padding: 6px 10px;
    border: 1px solid #e2ae76;
  }

  /* Optional: pagination or info text */
  .dataTables_wrapper .dataTables_info,
  .dataTables_wrapper .dataTables_paginate {
    color: #041930;
    font-weight: 500;
  }
</style>


<?php $__env->startSection('scripts'); ?>
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="https://cdn.datatables.net/1.13.6/js/jquery.dataTables.min.js"></script>
<script>
  document.addEventListener('DOMContentLoaded', () => {
    // Line Total Calculation
    document.querySelectorAll('.return-qty').forEach(input => {
      input.addEventListener('input', function () {
        const tr = this.closest('tr');
        const qty = parseFloat(this.value) || 0;
        const priceText = tr.querySelector('td:nth-child(6)').textContent;
        const price = parseFloat(priceText.replace(/[^0-9.]/g, '')) || 0;
        tr.querySelector('.total-return').value = (price * qty).toFixed(2);
      });
    });

    // DataTables init
    $('#returnTable').DataTable({
      paging: true,
      searching: true,
      ordering: true,
      order: [[0, 'asc']],
      columnDefs: [
        { className: "text-center", targets: "_all" }
      ]
    });
  });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Applications/XAMPP/htdocs/bakery/resources/views/frontend/returned-goods/form.blade.php ENDPATH**/ ?>