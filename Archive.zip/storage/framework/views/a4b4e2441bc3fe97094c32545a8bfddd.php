<?php $__env->startSection('title', isset($cost) ? 'Edit Cost' : 'Add Cost'); ?>

<?php $__env->startSection('content'); ?>
<div class="container py-5">
  <div class="card shadow-sm">
    <div class="card-header bg-warning text-dark">
      <h5 class="mb-0"><?php echo e(isset($cost) ? 'Edit Cost' : 'Add Cost'); ?></h5>
    </div>
    <div class="card-body">
      <form method="POST"
            action="<?php echo e(isset($cost) ? route('costs.update',$cost) : route('costs.store')); ?>"
            class="row g-3 needs-validation"
            novalidate>
        <?php echo csrf_field(); ?>
        <?php if(isset($cost)): ?> <?php echo method_field('PUT'); ?> <?php endif; ?>

        
        <div class="col-md-6">
          <label for="cost_identifier" class="form-label">Cost Identifier <small class="text-muted">(optional)</small></label>
          <input type="text"
                 name="cost_identifier"
                 id="cost_identifier"
                 class="form-control"
                 placeholder="e.g. INV‑2025‑04‑001"
                 value="<?php echo e(old('cost_identifier',$cost->cost_identifier ?? '')); ?>">
        </div>

        
        <div class="col-md-6">
          <label for="supplier" class="form-label">Supplier</label>
          <input type="text"
                 name="supplier"
                 id="supplier"
                 class="form-control"
                 placeholder="e.g. ABC Ltd."
                 value="<?php echo e(old('supplier',$cost->supplier ?? '')); ?>"
                 required>
          <div class="invalid-feedback">Please enter a supplier.</div>
        </div>

        
        <div class="col-md-6">
          <label for="amount" class="form-label">Amount</label>
          <div class="input-group has-validation">
            <span class="input-group-text">$</span>
            <input type="number" step="0.01"
                   name="amount"
                   id="amount"
                   class="form-control"
                   value="<?php echo e(old('amount',$cost->amount ?? '')); ?>"
                   required>
            <div class="invalid-feedback">Please enter a valid amount.</div>
          </div>
        </div>

        
        <div class="col-md-6">
          <label for="due_date" class="form-label">Due Date</label>
          <input type="date"
                 name="due_date"
                 id="due_date"
                 class="form-control"
                 value="<?php echo e(old('due_date',$cost->due_date ?? '')); ?>"
                 required>
          <div class="invalid-feedback">Please pick a date.</div>
        </div>

        
        <div class="col-md-6">
          <label for="category_id" class="form-label">Category</label>
          <select name="category_id" id="category_id" class="form-select" required>
            <option value="">Select…</option>
            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <option value="<?php echo e($c->id); ?>"
                <?php echo e(old('category_id',$cost->category_id??'')==$c->id?'selected':''); ?>>
                <?php echo e($c->name); ?>

              </option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </select>
          <div class="invalid-feedback">Please select a category.</div>
        </div>

        <div class="col-12 text-end">
          <button class="btn btn-warning">
            <i class="bi bi-save2 me-1"></i>
            <?php echo e(isset($cost)?'Update':'Save'); ?> Cost
          </button>
        </div>
      </form>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script>
(() => {
  'use strict';
  document.querySelectorAll('.needs-validation').forEach(form => {
    form.addEventListener('submit', e => {
      if (!form.checkValidity()) {
        e.preventDefault(); e.stopPropagation();
      }
      form.classList.add('was-validated');
    });
  });
})();
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Applications/XAMPP/htdocs/bakery/resources/views/frontend/costs/create.blade.php ENDPATH**/ ?>