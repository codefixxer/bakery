<?php $__env->startSection('title', $news->title); ?>

<?php $__env->startSection('content'); ?>
<div class="container py-5">
    <div class="row">
        <div class="col-12">
            <div class="card shadow-lg rounded-3">
                <div class="card-header" style="background-color: #041930; color: #e2ae76;">
                    <h2 class="mb-0" style="background-color: #041930; color: #e2ae76;" ><?php echo e($news->title); ?></h2>
                    <span class="badge bg-warning text-dark"><?php echo e($news->created_at->diffForHumans()); ?></span>
                </div>
                <div class="card-body">
                    <p class="text-muted"><?php echo e($news->content); ?></p>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Applications/XAMPP/htdocs/bakery/resources/views/frontend/news/show.blade.php ENDPATH**/ ?>