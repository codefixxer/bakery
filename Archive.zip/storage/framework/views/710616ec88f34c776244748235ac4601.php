<?php $__env->startSection('title', $recipe->recipe_name); ?>

<?php $__env->startSection('content'); ?>
<div class="container py-5">
  <div class="card shadow-sm">
    <div class="card-header bg-primary text-white">
      <h5 class="mb-0"><?php echo e($recipe->recipe_name); ?></h5>
    </div>
    <div class="card-body">
      
      <dl class="row">
        <dt class="col-sm-4 fw-semibold">Category:</dt>
        <dd class="col-sm-8"><?php echo e($recipe->category->name ?? '—'); ?></dd>

        <dt class="col-sm-4 fw-semibold">Department:</dt>
        <dd class="col-sm-8"><?php echo e($recipe->department->name ?? '—'); ?></dd>

        <dt class="col-sm-4 fw-semibold">Sell Mode:</dt>
        <dd class="col-sm-8 text-uppercase"><?php echo e($recipe->sell_mode); ?></dd>

        <dt class="col-sm-4 fw-semibold">Price:</dt>
        <?php
          $sell = $recipe->sell_mode === 'piece'
                  ? $recipe->selling_price_per_piece
                  : $recipe->selling_price_per_kg;
        ?>
        <dd class="col-sm-8">€<?php echo e(number_format($sell, 2)); ?></dd>

        <dt class="col-sm-4 fw-semibold">Ingredients Cost:</dt>
        <dd class="col-sm-8">€<?php echo e(number_format($recipe->ingredients_total_cost, 2)); ?></dd>

        <dt class="col-sm-4 fw-semibold">Labour Cost:</dt>
        <dd class="col-sm-8">€<?php echo e(number_format($recipe->labour_cost, 2)); ?></dd>

        <dt class="col-sm-4 fw-semibold">Total Cost:</dt>
        <?php
          $total = $recipe->ingredients_total_cost + $recipe->labour_cost;
        ?>
        <dd class="col-sm-8">€<?php echo e(number_format($total, 2)); ?></dd>

        <dt class="col-sm-4 fw-semibold">Margin:</dt>
        <?php
          $margin = $recipe->potential_margin;
          $pct    = $sell > 0 ? round($margin * 100 / $sell, 2) : 0;
        ?>
        <dd class="col-sm-8">
          <?php if($margin >= 0): ?>
            <span class="text-success">€<?php echo e(number_format($margin, 2)); ?> (<?php echo e($pct); ?>%)</span>
          <?php else: ?>
            <span class="text-danger">€<?php echo e(number_format($margin, 2)); ?> (<?php echo e($pct); ?>%)</span>
          <?php endif; ?>
        </dd>
      </dl>

      
      <h6 class="mt-4">Ingredients</h6>
      <div class="table-responsive">
        <table class="table table-sm table-bordered mb-0">
          <thead class="table-light">
            <tr>
              <th>Ingredient</th>
              <th class="text-end">Qty (g)</th>
              <th class="text-end">Cost (€)</th>
            </tr>
          </thead>
          <tbody>
            <?php $__currentLoopData = $recipe->ingredients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ing): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <tr>
                <td><?php echo e($ing->ingredient->ingredient_name); ?></td>
                <td class="text-end"><?php echo e($ing->quantity_g); ?></td>
                <td class="text-end"><?php echo e(number_format($ing->cost, 2)); ?></td>
              </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </tbody>
        </table>
      </div>

      
      <div class="mt-4">
        <a href="<?php echo e(route('recipes.edit', $recipe->id)); ?>" class="btn btn-primary me-2">
          <i class="bi bi-pencil me-1"></i>Edit
        </a>
        <a href="<?php echo e(route('recipes.index')); ?>" class="btn btn-secondary me-2">
          <i class="bi bi-list me-1"></i>Back to List
        </a>
        <form action="<?php echo e(route('recipes.destroy', $recipe->id)); ?>"
              method="POST"
              class="d-inline"
              onsubmit="return confirm('Delete this recipe?');">
          <?php echo csrf_field(); ?>
          <?php echo method_field('DELETE'); ?>
          <button type="submit" class="btn btn-danger">
            <i class="bi bi-trash me-1"></i>Delete
          </button>
        </form>
      </div>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Applications/XAMPP/htdocs/bakery/resources/views/frontend/recipe/show.blade.php ENDPATH**/ ?>