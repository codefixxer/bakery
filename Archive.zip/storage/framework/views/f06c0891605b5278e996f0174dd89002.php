<?php $__env->startSection('title', 'Recipe Sales by Date'); ?>

<?php $__env->startSection('content'); ?>
<div class="container py-5">

  
  <div class="card mb-4 shadow-sm">
    <div class="card-body">
      <form method="GET" class="row g-3 align-items-center">
        
        <div class="col-md-3">
          <label class="form-label">Product</label>
          <select name="recipe_id" class="form-select">
            <option value="">All products</option>
            <?php $__currentLoopData = $recipes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $name): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <option value="<?php echo e($id); ?>" <?php if($id == $recipeId): echo 'selected'; endif; ?>><?php echo e($name); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </select>
        </div>

        
        <div class="col-md-3">
          <label class="form-label">Category</label>
          <select name="category_id" class="form-select">
            <option value="">All categories</option>
            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <option value="<?php echo e($cat->id); ?>" <?php if($cat->id == $categoryId): echo 'selected'; endif; ?>><?php echo e($cat->name); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </select>
        </div>

        
        <div class="col-md-3">
          <label class="form-label">Department</label>
          <select name="department_id" class="form-select">
            <option value="">All departments</option>
            <?php $__currentLoopData = $departments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dept): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <option value="<?php echo e($dept->id); ?>" <?php if($dept->id == $departmentId): echo 'selected'; endif; ?>><?php echo e($dept->name); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </select>
        </div>

        
        <div class="col-md-2">
          <label class="form-label">From</label>
          <input type="date" name="start_date" class="form-control" value="<?php echo e($startDate); ?>">
        </div>
        <div class="col-md-2">
          <label class="form-label">To</label>
          <input type="date" name="end_date" class="form-control" value="<?php echo e($endDate); ?>">
        </div>

        
        <div class="col-md-2 text-end">
          <button class="btn btn-primary w-100">Filter</button>
        </div>
      </form>
    </div>
  </div>

  
  <div class="card shadow-sm">
    <div class="table-responsive">
      <table class="table table-striped table-bordered mb-0">
        <thead class="table-light">
          <tr>
            <th>Product</th>
            <th>Category</th>
            <th>Department</th>
            <th class="text-end">Pieces Sold</th>
            <th class="text-end">Waste</th>
            <th class="text-end">Total Revenue (€)</th>
          </tr>
        </thead>
        <tbody>
          <?php
            $grandSold = $grandWaste = $grandRevenue = 0;
          ?>

          <?php $__empty_1 = true; $__currentLoopData = $recordsByRecipe; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rId => $days): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <?php
              $rec     = $recipes->contains($rId) ? $recipes->get($rId) : '–';
              $model   = $days->first()->first()->recipe;
              $cat     = $model->category?->name ?? '–';
              $dept    = $model->department?->name ?? '–';
              $sold    = $days->flatten()->sum('sold');
              $waste   = $days->flatten()->sum('waste');
              $revenue = $days->flatten()->sum('actual_revenue');

              $grandSold    += $sold;
              $grandWaste   += $waste;
              $grandRevenue += $revenue;
            ?>

            
            <tr class="accordion-toggle" 
                data-bs-toggle="collapse"
                data-bs-target="#details-<?php echo e($rId); ?>"
                aria-expanded="false"
                style="cursor: pointer"
            >
              <td>
                <i class="bi bi-caret-down-fill me-1 toggle-icon" id="icon-<?php echo e($rId); ?>"></i>
                <?php echo e($model->recipe_name); ?>

              </td>
              <td><?php echo e($cat); ?></td>
              <td><?php echo e($dept); ?></td>
              <td class="text-end"><?php echo e($sold); ?></td>
              <td class="text-end"><?php echo e($waste); ?></td>
              <td class="text-end"><?php echo e(number_format($revenue, 2)); ?></td>
            </tr>

            
            <tr class="collapse" id="details-<?php echo e($rId); ?>">
              <td colspan="6" class="p-0">
                <table class="table table-sm mb-0">
                  <thead>
                    <tr class="table-light">
                      <th>Date</th>
                      <th class="text-end">Sold</th>
                      <th class="text-end">Waste</th>
                      <th class="text-end">Revenue (€)</th>
                    </tr>
                  </thead>
                  <tbody>
                    <?php $__currentLoopData = $days; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $date => $rowsOnDate): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <tr>
                        <td><?php echo e($date); ?></td>
                        <td class="text-end"><?php echo e($rowsOnDate->sum('sold')); ?></td>
                        <td class="text-end"><?php echo e($rowsOnDate->sum('waste')); ?></td>
                        <td class="text-end"><?php echo e(number_format($rowsOnDate->sum('actual_revenue'), 2)); ?></td>
                      </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </tbody>
                </table>
              </td>
            </tr>

          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <tr>
              <td colspan="6" class="text-center text-muted py-3">
                No data for that selection.
              </td>
            </tr>
          <?php endif; ?>
        </tbody>

        <?php if($recordsByRecipe->isNotEmpty()): ?>
          <tfoot class="table-light">
            <tr>
              <th colspan="3">Total</th>
              <th class="text-end"><?php echo e($grandSold); ?></th>
              <th class="text-end"><?php echo e($grandWaste); ?></th>
              <th class="text-end"><?php echo e(number_format($grandRevenue, 2)); ?></th>
            </tr>
          </tfoot>
        <?php endif; ?>
      </table>
    </div>
  </div>

</div>
<?php $__env->stopSection(); ?>


<?php $__env->startPush('scripts'); ?>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3/dist/js/bootstrap.bundle.min.js"></script>

<script>
  document.addEventListener('DOMContentLoaded', function () {
    // Get all collapsible elements (the table rows)
    const collapsibleElements = document.querySelectorAll('.accordion-toggle');
    
    collapsibleElements.forEach(item => {
      item.addEventListener('click', function () {
        // Get target ID and icon
        const targetId = item.getAttribute('data-bs-target').substring(1); // Remove the '#' character
        const icon = document.getElementById('icon-' + targetId);

        // Toggle the collapse
        const collapseElement = document.getElementById(targetId);

        // Check if collapse is open or closed and toggle icon accordingly
        if (collapseElement.classList.contains('show')) {
          icon.classList.remove('bi-caret-up-fill');
          icon.classList.add('bi-caret-down-fill');
        } else {
          icon.classList.remove('bi-caret-down-fill');
          icon.classList.add('bi-caret-up-fill');
        }
      });
    });
  });
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('frontend.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Applications/XAMPP/htdocs/bakery/resources/views/frontend/showcase/recipe-sales.blade.php ENDPATH**/ ?>