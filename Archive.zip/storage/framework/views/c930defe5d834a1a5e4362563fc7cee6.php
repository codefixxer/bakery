<?php $__env->startSection('title', 'Production: ' . $production->production_date); ?>

<?php $__env->startSection('content'); ?>
<div class="container py-5 px-md-4">

  
  <div class="card border-primary shadow-lg rounded-3 overflow-hidden">

    
    <div class="card-header d-flex align-items-center" style="background-color: #041930;">
      <i class="bi bi-gear-fill fs-4 me-3" style="color: #e2ae76;"></i>
      <h5 class="mb-0 fw-bold" style="color: #e2ae76;">
        Production Record: <?php echo e($production->production_date); ?>

      </h5>
    </div>

    <div class="card-body">

      
      <div class="row mb-4 align-items-center">
        <div class="col-md-4">
          <h6 class="text-uppercase text-muted small">Items Produced</h6>
          <p class="fs-4 fw-bold mb-0"><?php echo e($production->details->count()); ?></p>
        </div>
        <div class="col-md-4">
          <h6 class="text-uppercase text-muted small">Total Potential (€)</h6>
          <p class="fs-4 fw-bold mb-0">
            €<?php echo e(number_format($production->total_potential_revenue, 2)); ?>

          </p>
        </div>
        <div class="col-md-4 text-end">
          <a href="<?php echo e(route('production.edit', $production)); ?>"
             class="btn btn-gold btn-sm me-1">
            <i class="bi bi-pencil me-1"></i>Edit
          </a>
          <a href="<?php echo e(route('production.index')); ?>"
             class="btn btn-deepblue btn-sm me-1">
            <i class="bi bi-arrow-left me-1"></i>Back
          </a>
          <form action="<?php echo e(route('production.destroy', $production)); ?>"
                method="POST" class="d-inline"
                onsubmit="return confirm('Delete this record?');">
            <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
            <button type="submit" class="btn btn-red btn-sm">
              <i class="bi bi-trash me-1"></i>Delete
            </button>
          </form>
        </div>
      </div>

      
      <form method="GET" class="row mb-3 gx-2 gy-2">
        
        <div class="col-auto">
          <select name="chef_id"
                  class="form-select form-select-sm"
                  onchange="this.form.submit()">
            <option value="">All Chefs</option>
            <?php $__currentLoopData = $allChefs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $name): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <option value="<?php echo e($id); ?>"
                <?php echo e($id == $selectedChef ? 'selected' : ''); ?>>
                <?php echo e($name); ?>

              </option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </select>
        </div>

        
        <div class="col-auto">
          <?php
            $opposite = $sortDir==='asc' ? 'desc':'asc';
            $qs = array_merge(request()->all(),[
              'sort'=>'chef','direction'=>$opposite
            ]);
          ?>
          <a href="?<?php echo e(http_build_query($qs)); ?>"
             class="btn btn-sm btn-outline-secondary">
            Sort by Chef
            <?php if($sortDir==='asc'): ?> ↑ <?php else: ?> ↓ <?php endif; ?>
          </a>
        </div>

        
        <div class="col-auto">
          <button type="button"
                  class="btn btn-sm btn-outline-primary"
                  onclick="window.print()">
            Print table
          </button>
        </div>
      </form>

      
      <div class="table-responsive">
        <table class="table table-bordered mb-0 align-middle text-center print-only-table">
          <thead style="background-color: #e2ae76; color: #041930;">
            <tr>
              <th>Recipe</th>
              <th>Chef</th>
              <th>Qty</th>
              <th>Exec Time (m)</th>
              <th>Equipment</th>
              <th>Potential (€)</th>
            </tr>
          </thead>
          <tbody>
            <?php
              $totalQty       = 0;
              $totalExecTime  = 0;
              $totalPotential = 0;
            ?>

            <?php $__currentLoopData = $details; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $detail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <?php
                // resolve equipment names
                $ids   = is_array($detail->equipment_ids)
                          ? $detail->equipment_ids
                          : (strlen($detail->equipment_ids)
                              ? explode(',', $detail->equipment_ids)
                              : []);
                $names = collect($ids)
                         ->map(fn($i)=>($equipmentMap[trim($i)] ?? null))
                         ->filter()->unique()->values();
                $equip = $names->implode(', ');

                // accumulate totals
                $totalQty       += $detail->quantity;
                $totalExecTime  += $detail->execution_time;
                $totalPotential += $detail->potential_revenue;
              ?>

              <tr>
                <td><?php echo e($detail->recipe->recipe_name); ?></td>
                <td><?php echo e($detail->chef->name); ?></td>
                <td><?php echo e($detail->quantity); ?></td>
                <td><?php echo e($detail->execution_time); ?></td>
                <td><?php echo e($equip); ?></td>
                <td>€<?php echo e(number_format($detail->potential_revenue, 2)); ?></td>
              </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            
            <tr class="fw-bold">
              <td colspan="2" class="text-end">Total:</td>
              <td><?php echo e($totalQty); ?></td>
              <td><?php echo e($totalExecTime); ?></td>
              <td></td>
              <td>€<?php echo e(number_format($totalPotential, 2)); ?></td>
            </tr>
          </tbody>
        </table>
      </div>
    </div>
  </div>
</div>


<style>
  .btn-gold {
    border: 1px solid #e2ae76!important;
    color: #e2ae76!important;
    background: transparent!important;
  }
  .btn-gold:hover {
    background: #e2ae76!important;
    color: #fff!important;
  }
  .btn-deepblue {
    border: 1px solid #041930!important;
    color: #041930!important;
    background: transparent!important;
  }
  .btn-deepblue:hover {
    background: #041930!important;
    color: #fff!important;
  }
  .btn-red {
    border: 1px solid red!important;
    color: red!important;
    background: transparent!important;
  }
  .btn-red:hover {
    background: red!important;
    color: #fff!important;
  }

  /* --- PRINT STYLES --- */
  @media print {
    body * { visibility: hidden; }
    .print-only-table, .print-only-table * {
      visibility: visible;
    }
    .print-only-table {
      position: absolute;
      top: 0; left: 0;
      width: 100%;
    }
  }
</style>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Applications/XAMPP/htdocs/bakery/resources/views/frontend/production/show.blade.php ENDPATH**/ ?>