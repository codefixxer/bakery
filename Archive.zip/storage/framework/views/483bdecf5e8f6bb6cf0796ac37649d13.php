<?php $__env->startSection('title', 'News & Blog'); ?>

<?php $__env->startSection('content'); ?>
<div class="container py-5">

    <!-- Top-Rated & Featured Section -->
    <div class="row mb-4">
        <div class="col-12">
            <h2 class="text-center text-dark">Top Rated Blogs</h2>
            <p class="text-center text-muted">Discover our most popular and top-rated blogs for insights and expert advice.</p>
        </div>
    </div>

    <div class="row gy-4">
        <?php $__currentLoopData = $news; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-md-6 col-lg-4">
                <div class="card h-100 shadow-lg rounded-3 overflow-hidden">
                    <div class="card-header" style="background-color: #041930; color: #e2ae76;">
                        <h5 class="mb-0" style="background-color: #041930; color: #e2ae76;"><?php echo e($item->title); ?></h5>
                        <span class="badge bg-warning text-dark"><?php echo e($item->created_at->diffForHumans()); ?></span>
                    </div>
                    <div class="card-body">
                        <p class="text-muted"><?php echo e(Str::limit($item->content, 150)); ?></p>
                    </div>
                    <div class="card-footer text-end"  ">
                        <a href="<?php echo e(route('news.show', $item->id)); ?>" class="btn btn-primary btn-sm " style="background-color:#e2ae76 ; color:#041930; border:#e2ae76">Read More</a>
                    </div>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        <!-- Empty state if no news -->
        <?php if($news->isEmpty()): ?>
            <div class="col-12 text-center text-muted">
                <p>No news posts found.</p>
            </div>
        <?php endif; ?>
    </div>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Applications/XAMPP/htdocs/bakery/resources/views/frontend/news/blogs.blade.php ENDPATH**/ ?>