<?php $__env->startSection('title', isset($category) ? 'Edit Category' : 'Add Category'); ?>

<?php $__env->startSection('content'); ?>
<div class="container py-5">
  <div class="card border-primary shadow-sm">
    <div class="card-header bg-primary text-white d-flex align-items-center">
      <i class="bi bi-tags fs-4 me-2"></i>
      <h5 class="mb-0"><?php echo e(isset($category) ? 'Edit Category' : 'Add Category'); ?></h5>
    </div>
    <div class="card-body"> 
    <form 
  action="<?php echo e(isset($category) ? route('cost_categories.update', $category->id) : route('cost_categories.store')); ?>" 
  method="POST"
  class="needs-validation"
  novalidate
>
        <?php echo csrf_field(); ?>
        <?php if(isset($category)): ?>
          <?php echo method_field('PUT'); ?>
        <?php endif; ?>

        <div class="mb-3">
          <label for="name" class="form-label fw-semibold">Category Name</label>
          <input
            type="text"
            name="name"
            id="name"
            class="form-control form-control-lg"
            placeholder="e.g. Utilities, Rent, Packaging"
            value="<?php echo e(old('name', $category->name ?? '')); ?>"
            required
          >
          <div class="invalid-feedback">
            Please enter a category name.
          </div>
        </div>

        <div class="text-end">
          <button type="submit" class="btn btn-lg btn-primary">
            <i class="bi bi-save2 me-2"></i> <?php echo e(isset($category) ? 'Update' : 'Save Category'); ?>

          </button>
        </div>
      </form>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script>
// Bootstrap form validation
(() => {
  'use strict'
  const forms = document.querySelectorAll('.needs-validation')
  Array.from(forms).forEach(form => {
    form.addEventListener('submit', event => {
      if (!form.checkValidity()) {
        event.preventDefault()
        event.stopPropagation()
      }
      form.classList.add('was-validated')
    }, false)
  })
})()
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Applications/XAMPP/htdocs/bakery/resources/views/frontend/categories/create.blade.php ENDPATH**/ ?>