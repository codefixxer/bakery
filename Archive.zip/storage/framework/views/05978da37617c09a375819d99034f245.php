<?php $__env->startSection('title', 'Roles & Permissions'); ?>

<?php $__env->startSection('content'); ?>
<div class="container py-5 px-md-5">

  <!-- Header -->
  <div class="page-header d-flex align-items-center mb-4" style="background-color: #041930; border-radius: 0.75rem; padding: 1rem 2rem;">
    <i class="bi bi-shield-lock me-2 fs-3" style="color: #e2ae76;"></i>
    <h2 class="mb-0 fw-bold" style="color: #e2ae76;">Roles & Permissions</h2>
  </div>

  <!-- Add Button -->
  <div class="d-flex justify-content-end mb-3">
    <a href="<?php echo e(route('roles.create')); ?>" class="btn btn-gold-blue">
      <i class="bi bi-plus-circle me-1"></i> Add Role
    </a>
  </div>

  <!-- Table -->
  <div class="card shadow-lg border-0 rounded-3">
    <div class="card-body p-0">
      <div class="table-responsive">
        <table class="table table-hover table-bordered table-striped mb-0">
          <thead style="background-color: #e2ae76; color: #041930;">
            <tr class="text-center">
              <th style="font-size: 16px; font-weight: 600;">Role Name</th>
              <th style="font-size: 16px; font-weight: 600;">Permissions</th>
              <th style="font-size: 16px; font-weight: 600;">Actions</th>
            </tr>
          </thead>
          <tbody>
            <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <tr>
                <td class="align-middle text-center fw-semibold"><?php echo e(ucfirst($role->name)); ?></td>
                <td class="align-middle text-center">
                  <?php $__empty_1 = true; $__currentLoopData = $role->permissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $permission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <span class="badge bg-secondary text-light m-1"><?php echo e($permission->name); ?></span>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <span class="text-muted">—</span>
                  <?php endif; ?>
                </td>
                <td class="text-center align-middle">
                  <a href="<?php echo e(route('roles.edit', $role)); ?>" class="btn btn-sm btn-gold me-1">
                    <i class="bi bi-pencil"></i> Edit
                  </a>
                  <form action="<?php echo e(route('roles.destroy', $role)); ?>" method="POST" class="d-inline" onsubmit="return confirm('Delete role?');">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('DELETE'); ?>
                    <button type="submit" class="btn btn-sm btn-red">
                      <i class="bi bi-trash"></i> Delete
                    </button>
                  </form>
                </td>
              </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </tbody>
        </table>
      </div>
    </div>
  </div>

</div>
<?php $__env->stopSection(); ?>

<style>
  .btn-gold-blue {
    background-color: #e2ae76 !important;
    color: #041930 !important;
    border: 1px solid #e2ae76;
  }
  .btn-gold-blue:hover {
    background-color: #d89d5c !important;
    color: white !important;
  }
  .btn-gold {
    border: 1px solid #e2ae76 !important;
    color: #e2ae76 !important;
    background-color: transparent !important;
  }
  .btn-gold:hover {
    background-color: #e2ae76 !important;
    color: #041930 !important;
  }
  .btn-red {
    border: 1px solid red !important;
    color: red !important;
    background-color: transparent !important;
  }
  .btn-red:hover {
    background-color: red !important;
    color: white !important;
  }
</style>


<?php echo $__env->make('frontend.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Applications/XAMPP/htdocs/bakery/resources/views/frontend/user-management/roles/index.blade.php ENDPATH**/ ?>