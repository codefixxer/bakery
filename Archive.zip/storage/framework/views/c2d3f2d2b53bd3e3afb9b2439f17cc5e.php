<?php $__env->startSection('title', isset($income) ? 'Edit Income' : 'Add Income'); ?>

<?php $__env->startSection('content'); ?>
<div class="container py-5">
  <div class="card shadow-sm">
    <div class="card-header bg-success text-white">
      <h5 class="mb-0"><?php echo e(isset($income) ? 'Edit' : 'Add'); ?> Income</h5>
    </div>
    <div class="card-body">
      <form
        action="<?php echo e(isset($income) ? route('incomes.update',$income) : route('incomes.store')); ?>"
        method="POST"
        class="row g-3 needs-validation" novalidate
      >
        <?php echo csrf_field(); ?>
        <?php if(isset($income)): ?> <?php echo method_field('PUT'); ?> <?php endif; ?>

        <div class="col-md-6">
          <label for="amount" class="form-label">Amount ($)</label>
          <div class="input-group has-validation">
            <span class="input-group-text"><i class="bi bi-currency-dollar"></i></span>
            <input
              type="number"
              step="0.01"
              name="amount"
              id="amount"
              class="form-control <?php $__errorArgs = ['amount'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
              value="<?php echo e(old('amount', $income->amount ?? '')); ?>"
              required
            >
            <div class="invalid-feedback"><?php echo e($errors->first('amount')); ?></div>
          </div>
        </div>

        <div class="col-md-6">
          <label for="date" class="form-label">Date</label>
          <input
            type="date"
            name="date"
            id="date"
            class="form-control <?php $__errorArgs = ['date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
            value="<?php echo e(old('date', isset($income) ? $income->date->format('Y-m-d') : '')); ?>"
            required
          >
          <div class="invalid-feedback"><?php echo e($errors->first('date')); ?></div>
        </div>

        <div class="col-12 text-end">
          <button class="btn btn-success">
            <i class="bi bi-save2 me-1"></i>
            <?php echo e(isset($income) ? 'Update' : 'Save'); ?> Income
          </button>
        </div>
      </form>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script>
// Bootstrap form validation
(() => {
  'use strict';
  document.querySelectorAll('.needs-validation').forEach(form => {
    form.addEventListener('submit', e => {
      if (!form.checkValidity()) {
        e.preventDefault();
        e.stopPropagation();
      }
      form.classList.add('was-validated');
    });
  });
})();
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Applications/XAMPP/htdocs/bakery/resources/views/frontend/incomes/create.blade.php ENDPATH**/ ?>