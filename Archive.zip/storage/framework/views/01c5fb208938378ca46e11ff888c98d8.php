<?php $__env->startSection('title', $returnedGood->exists ? 'Edit Returned Goods' : 'Create Returned Goods'); ?>

<?php $__env->startSection('content'); ?>
<div class="container py-5">
  <h2 class="mb-4">
    <?php echo e($returnedGood->exists ? 'Edit' : 'Create'); ?> Returned Goods
  </h2>

  <form
    method="POST"
    action="<?php echo e($returnedGood->exists
                ? route('returned-goods.update', $returnedGood)
                : route('returned-goods.store')); ?>">
    <?php echo csrf_field(); ?>
    <?php if($returnedGood->exists): ?>
      <?php echo method_field('PUT'); ?>
    <?php endif; ?>

    
    <div class="row mb-4 g-3">
      <div class="col-md-6">
        <label class="form-label">Client</label>
        <select name="client_id" class="form-select" required>
          <option value="">Select…</option>
          <?php $__currentLoopData = $clients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($c->id); ?>"
              <?php echo e(old('client_id', $returnedGood->client_id) == $c->id ? 'selected' : ''); ?>>
              <?php echo e($c->name); ?>

            </option>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
      </div>
      <div class="col-md-6">
        <label class="form-label">Return Date</label>
        <input
          type="date"
          name="return_date"
          class="form-control"
          value="<?php echo e(old('return_date',
                        $returnedGood->return_date
                          ? $returnedGood->return_date->format('Y-m-d')
                          : ''
                      )); ?>"
          required
        >
      </div>
    </div>

    
    <div class="card mb-4">
      <div class="card-header bg-secondary text-white"><strong>Returned Items</strong></div>
      <div class="card-body p-0">
        <table class="table mb-0 align-middle">
          <thead class="table-light">
            <tr>
              <th>Recipe</th>
              <th>Price</th>
              <th>Qty</th>
              <th>Total</th>
              <th></th>
            </tr>
          </thead>
          <tbody id="linesTable">
            <?php
              // decide which set of lines to render:
              if(old('recipes')) {
                $lines = old('recipes');
              } elseif($returnedGood->exists) {
                $lines = $returnedGood->recipes->map(fn($r)=>[
                  'id'           => $r->recipe_id,
                  'price'        => $r->price,
                  'qty'          => $r->qty,
                  'total_amount' => $r->total_amount,
                ])->toArray();
              } else {
                $lines = [['id'=>'','price'=>'','qty'=>1,'total_amount'=>'']];
              }
            ?>

            <?php $__currentLoopData = $lines; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $line): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <tr class="line-row">
                <td>
                  <select name="recipes[<?php echo e($i); ?>][id]" class="form-select recipe-select" required>
                    <option value="">Select…</option>
                    <?php $__currentLoopData = $recipes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <option
                        value="<?php echo e($r->id); ?>"
                        data-price="<?php echo e($r->sell_mode==='kg'
                                      ? $r->selling_price_per_kg
                                      : $r->selling_price_per_piece); ?>"
                        data-unit="<?php echo e($r->sell_mode); ?>"
                        <?php echo e((int)($line['id'] ?? '') === $r->id ? 'selected' : ''); ?>>
                        <?php echo e($r->recipe_name); ?>

                      </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </select>
                </td>
                <td>
                  <div class="input-group">
                    <span class="input-group-text">€</span>
                    <input
                      type="text"
                      name="recipes[<?php echo e($i); ?>][price]"
                      class="form-control price-field"
                      readonly
                      value="<?php echo e($line['price'] ?? ''); ?>"
                    >
                    <span class="input-group-text unit-span"></span>
                  </div>
                </td>
                <td>
                  <input
                    type="number"
                    name="recipes[<?php echo e($i); ?>][qty]"
                    class="form-control qty-field"
                    min="1"
                    value="<?php echo e($line['qty'] ?? 1); ?>"
                    required
                  >
                </td>
                <td>
                  <input
                    type="text"
                    name="recipes[<?php echo e($i); ?>][total_amount]"
                    class="form-control total-field"
                    readonly
                    value="<?php echo e($line['total_amount'] ?? ''); ?>"
                  >
                </td>
                <td>
                  <button type="button" class="btn btn-sm btn-outline-danger remove-line">
                    <i class="bi bi-trash"></i>
                  </button>
                </td>
              </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </tbody>
        </table>
        <div class="p-3 text-end">
          <button type="button" id="addLineBtn" class="btn btn-sm btn-outline-success">
            <i class="bi bi-plus-lg"></i> Add Item
          </button>
        </div>
      </div>
    </div>

    
    <div class="mb-4">
      <label class="form-label">Total Returned (€)</label>
      <input
        type="text"
        name="total_amount"
        id="grandTotal"
        class="form-control"
        readonly
        value="<?php echo e(old('total_amount', $returnedGood->total_amount)); ?>"
      >
    </div>

    <button type="submit" class="btn btn-primary">
      <i class="bi bi-save2 me-1"></i>
      <?php echo e($returnedGood->exists ? 'Update' : 'Save'); ?>

    </button>
  </form>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script>
document.addEventListener('DOMContentLoaded', () => {
  let idx       = document.querySelectorAll('.line-row').length;
  const table   = document.getElementById('linesTable');
  const addBtn  = document.getElementById('addLineBtn');

  // 1) Add new blank row
  addBtn.addEventListener('click', () => {
    const first = table.querySelector('.line-row');
    const tr    = first.cloneNode(true);
    tr.querySelectorAll('input,select').forEach(el => {
      el.name = el.name.replace(/\[\d+\]/, `[${idx}]`);
      if (el.tagName === 'SELECT') {
        el.selectedIndex = 0;
      } else if (el.type === 'number') {
        el.value = '1';
      } else {
        el.value = '';
      }
    });
    table.appendChild(tr);
    idx++;
  });

  // 2) Recalc a single row
  function recalc(tr) {
    const opt   = tr.querySelector('.recipe-select').selectedOptions[0];
    const price = parseFloat(opt.dataset.price||0).toFixed(2);
    const unit  = opt.dataset.unit==='kg' ? '/kg' : '/pz';
    tr.querySelector('.price-field').value = price;
    tr.querySelector('.unit-span').textContent = unit;
    const qty   = parseFloat(tr.querySelector('.qty-field').value||0);
    tr.querySelector('.total-field').value = (price*qty).toFixed(2);
    recalcGrand();
  }

  // 3) Grand total
  function recalcGrand(){
    let sum = 0;
    document.querySelectorAll('.total-field')
            .forEach(i => sum += parseFloat(i.value)||0);
    document.getElementById('grandTotal').value = sum.toFixed(2);
  }

  // 4) Delegate
  table.addEventListener('change', e => {
    if (e.target.classList.contains('recipe-select'))
      recalc(e.target.closest('tr'));
  });
  table.addEventListener('input', e => {
    if (e.target.classList.contains('qty-field'))
      recalc(e.target.closest('tr'));
  });
  table.addEventListener('click', e => {
    if (e.target.closest('.remove-line')
        && table.querySelectorAll('.line-row').length > 1) {
      e.target.closest('tr').remove();
      recalcGrand();
    }
  });

  // 5) Initialize existing rows on load
  document.querySelectorAll('.line-row').forEach(r => recalc(r));
});
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Applications/XAMPP/htdocs/bakery/resources/views/frontend/returned-goods/create.blade.php ENDPATH**/ ?>