<?php $__env->startSection('title', 'Showcase & External Supply Records'); ?>

<?php $__env->startSection('content'); ?>
<div class="container py-5">
  
  <div class="text-center mb-4">
    <h2 class="d-inline-block px-4 py-2" style="background:#041930; color:#e2ae76; border-radius:.5rem;">
      Showcase &amp; External Supply Records
    </h2>
  </div>

  
  <div class="card mb-4 shadow-sm border-0">
    <div class="card-body">
      <div class="row g-3">
        <div class="col-md-2">
          <label class="form-label">From</label>
          <input id="filter-from" type="date" value="<?php echo e($from); ?>" class="form-control">
        </div>
        <div class="col-md-2">
          <label class="form-label">To</label>
          <input id="filter-to" type="date" value="<?php echo e($to); ?>" class="form-control">
        </div>
        <div class="col-md-3">
          <label class="form-label">Recipe Name</label>
          <input id="filter-recipe" type="text" class="form-control" placeholder="Enter recipe…">
        </div>
        <div class="col-md-2">
          <label class="form-label">Category</label>
          <select id="filter-category" class="form-select">
            <option value="">All Categories</option>
            <?php $__currentLoopData = $showcaseGroups->flatten(1)->pluck('recipes.*.recipe.category.name')->flatten()->unique(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <?php if($cat): ?>
                <option value="<?php echo e(strtolower($cat)); ?>"><?php echo e($cat); ?></option>
              <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </select>
        </div>
        <div class="col-md-2">
          <label class="form-label">Department</label>
          <select id="filter-department" class="form-select">
            <option value="">All Departments</option>
            <?php $__currentLoopData = $showcaseGroups->flatten(1)->pluck('recipes.*.recipe.department.name')->flatten()->unique(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dept): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <?php if($dept): ?>
                <option value="<?php echo e(strtolower($dept)); ?>"><?php echo e($dept); ?></option>
              <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </select>
        </div>
      </div>
    </div>
  </div>

  
  <div class="row mb-5 gx-4">
    <div class="col-md-6">
      <div class="card shadow-sm border-0">
        <div class="card-body text-center">
          <i class="bi bi-graph-up display-4 text-primary mb-2"></i>
          <h5>Total Showcase Revenue</h5>
          <p id="summary-showcase" class="display-6 mb-1"><?php echo e(number_format($totalShowcaseRevenue,2)); ?></p>
          <small id="summary-showcase-pct" class="text-muted">0%</small>
        </div>
      </div>
    </div>
    <div class="col-md-6">
      <div class="card shadow-sm border-0">
        <div class="card-body text-center">
          <i class="bi bi-currency-dollar display-4 text-danger mb-2"></i>
          <h5>Total External Cost</h5>
          <p id="summary-external" class="display-6 mb-1"><?php echo e(number_format($totalExternalCost,2)); ?></p>
          <small id="summary-external-pct" class="text-muted">0%</small>
        </div>
      </div>
    </div>
  </div>

  <div class="row gx-4">
    
    <div class="col-lg-6 mb-5">
      <div style="background:#041930; color:#e2ae76; padding:.5rem; border-top-left-radius:.5rem; border-top-right-radius:.5rem;">
        <i class="bi bi-list-ul me-1"></i> Showcase Records
      </div>
      <table class="table mb-0 border showcaseTable">
        <thead class="table-light text-center">
          <tr>
            <th style="width:1%"></th>
            <th>Date</th>
            <th>Recipe</th>
            <th>Qty</th>
            <th>Sold</th>
            <th>Reuse</th>
            <th>Waste</th>
            <th class="text-end">Revenue (€)</th>
          </tr>
        </thead>
        <tbody>
          <?php $__currentLoopData = $showcaseGroups; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $date => $group): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php
              $lines = $group->flatMap(fn($sc)=> $sc->recipes);
              $sum   = $lines->sum('actual_revenue');
            ?>
            <tr class="bg-light group-header text-center" data-date="<?php echo e($date); ?>">
              <td class="toggle-arrow" style="cursor:pointer">
                <i class="bi bi-caret-right-fill"></i>
              </td>
              <td colspan="6" class="text-start"><?php echo e($date); ?> (<?php echo e($lines->count()); ?> lines)</td>
              <td class="text-end fw-semibold"><?php echo e(number_format($sum,2)); ?></td>
            </tr>
            <?php $__currentLoopData = $group; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <?php $__currentLoopData = $sc->recipes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $line): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr class="group-<?php echo e($date); ?> d-none text-center"
                    data-date="<?php echo e($date); ?>"
                    data-recipe="<?php echo e(strtolower($line->recipe->recipe_name)); ?>"
                    data-category="<?php echo e(strtolower($line->recipe->category->name ?? '')); ?>"
                    data-department="<?php echo e(strtolower($line->recipe->department->name ?? '')); ?>"
                    data-qty="<?php echo e($line->quantity); ?>"
                    data-sold="<?php echo e($line->sold); ?>"
                    data-reuse="<?php echo e($line->reuse); ?>"
                    data-waste="<?php echo e($line->waste); ?>"
                    data-revenue="<?php echo e($line->actual_revenue); ?>">
                  <td></td>
                  <td><?php echo e($sc->showcase_date->format('Y-m-d')); ?></td>
                  <td><?php echo e($line->recipe->recipe_name); ?></td>
                  <td><?php echo e($line->quantity); ?></td>
                  <td><?php echo e($line->sold); ?></td>
                  <td><?php echo e($line->reuse); ?></td>
                  <td><?php echo e($line->waste); ?></td>
                  <td class="text-end"><?php echo e(number_format($line->actual_revenue,2)); ?></td>
                </tr>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
        <tfoot class="table-light text-center">
          <tr>
            <th colspan="3" class="text-end">Grand Total:</th>
            <th id="showcaseQtyFooter">0</th>
            <th id="showcaseSoldFooter">0</th>
            <th id="showcaseReuseFooter">0</th>
            <th id="showcaseWasteFooter">0</th>
            <th id="showcaseFooter">0.00</th>
          </tr>
        </tfoot>
      </table>
    </div>

    
    <div class="col-lg-6 mb-5">
      <div style="background:#041930; color:#e2ae76; padding:.5rem; border-top-left-radius:.5rem; border-top-right-radius:.5rem;">
        <i class="bi bi-box-seam me-1"></i> External Supply Records
      </div>
      <table class="table mb-0 border externalTable">
        <thead class="table-light text-center">
          <tr>
            <th style="width:1%"></th>
            <th>Date</th>
            <th>Client</th>
            <th>Recipe</th>
            <th>Returns</th>
            <th>Qty</th>
            <th class="text-end">Total (€)</th>
          </tr>
        </thead>
        <tbody>
          <?php $__currentLoopData = $externalGroups; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $date => $group): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php
              $lines = $group->flatMap(fn($es)=> $es->recipes);
              $sum   = $lines->sum(function($line){
                $unit     = $line->qty>0?($line->total_amount/$line->qty):0;
                $returned = $line->returns->sum('qty') * $unit;
                return $line->total_amount - $returned;
              });
            ?>
            <tr class="bg-light group-header text-center" data-date="<?php echo e($date); ?>">
              <td class="toggle-arrow" style="cursor:pointer">
                <i class="bi bi-caret-right-fill"></i>
              </td>
              <td colspan="5" class="text-start"><?php echo e($date); ?> (<?php echo e($lines->count()); ?> lines)</td>
              <td class="text-end fw-semibold"><?php echo e(number_format($sum,2)); ?></td>
            </tr>
            <?php $__currentLoopData = $group; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $es): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <?php $__currentLoopData = $es->recipes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $line): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php
                  $unit     = $line->qty>0?($line->total_amount/$line->qty):0;
                  $rQty     = $line->returns->sum('qty');
                  $netTotal = $line->total_amount - $rQty * $unit;
                ?>
                <tr class="group-<?php echo e($date); ?> d-none text-center"
                    data-date="<?php echo e($date); ?>"
                    data-recipe="<?php echo e(strtolower($line->recipe->recipe_name)); ?>"
                    data-category="<?php echo e(strtolower($line->recipe->category->name ?? '')); ?>"
                    data-department="<?php echo e(strtolower($line->recipe->department->name ?? '')); ?>"
                    data-returns="<?php echo e($rQty); ?>"
                    data-qty="<?php echo e($line->qty); ?>"
                    data-total="<?php echo e($netTotal); ?>">
                  <td></td>
                  <td><?php echo e($es->supply_date->format('Y-m-d')); ?></td>
                  <td><?php echo e($es->client->name); ?></td>
                  <td><?php echo e($line->recipe->recipe_name); ?></td>
                  <td><?php echo e($rQty); ?></td>
                  <td><?php echo e($line->qty); ?></td>
                  <td class="text-end"><?php echo e(number_format($netTotal,2)); ?></td>
                </tr>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
        <tfoot class="table-light text-center">
          <tr>
            <th colspan="4" class="text-end">Grand Total:</th>
            <th id="externalReturnsFooter">0</th>
            <th id="externalQtyFooter">0</th>
            <th id="externalFooter">0.00</th>
          </tr>
        </tfoot>
      </table>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script>
document.addEventListener('DOMContentLoaded', () => {
  const fromIn     = document.getElementById('filter-from');
  const toIn       = document.getElementById('filter-to');
  const recIn      = document.getElementById('filter-recipe');
  const catIn      = document.getElementById('filter-category');
  const deptIn     = document.getElementById('filter-department');

  const sumShowEl      = document.getElementById('summary-showcase');
  const pctShowEl      = document.getElementById('summary-showcase-pct');
  const sumExtEl       = document.getElementById('summary-external');
  const pctExtEl       = document.getElementById('summary-external-pct');
  const footerShowEl   = document.getElementById('showcaseFooter');
  const qtyShowEl      = document.getElementById('showcaseQtyFooter');
  const soldShowEl     = document.getElementById('showcaseSoldFooter');
  const reuseShowEl    = document.getElementById('showcaseReuseFooter');
  const wasteShowEl    = document.getElementById('showcaseWasteFooter');
  const footerExtEl    = document.getElementById('externalFooter');
  const retExtEl       = document.getElementById('externalReturnsFooter');
  const qtyExtEl       = document.getElementById('externalQtyFooter');

  function applyFilter() {
    const f = val => !val || val.trim()==='';
    const from  = fromIn.value;
    const to    = toIn.value;
    const rf    = recIn.value.trim().toLowerCase();
    const cf    = catIn.value.trim().toLowerCase();
    const df    = deptIn.value.trim().toLowerCase();

    let showSum=0, extSum=0;
    let qtySum=0, soldSum=0, reuseSum=0, wasteSum=0;
    let retSum=0, extQtySum=0;

    // utility to test one row
    function test(row, dataField, filterVal, matchExact=false) {
      const v = (row.dataset[dataField]||'').toString().toLowerCase();
      return !filterVal
          || (!matchExact ? v.includes(filterVal) : v===filterVal);
    }

    // process Showcase
    document.querySelectorAll('.showcaseTable .group-header').forEach(h=>{
      const date = h.dataset.date;
      let groupVisible = false;
      document.querySelectorAll(`.showcaseTable .group-${date}`).forEach(r=>{
        const okDate = (!from || r.dataset.date>=from)
                    && (!to   || r.dataset.date<=to);
        const okRec  = test(r,'recipe', rf);
        const okCat  = test(r,'category', cf, true);
        const okDep  = test(r,'department', df, true);
        const show   = okDate && okRec && okCat && okDep;
        r.classList.toggle('d-none', !show);
        if(show) {
          groupVisible = true;
          // accumulate
          qtySum   += +r.dataset.qty   || 0;
          soldSum  += +r.dataset.sold  || 0;
          reuseSum += +r.dataset.reuse || 0;
          wasteSum += +r.dataset.waste || 0;
          showSum  += +r.dataset.revenue||0;
        }
      });
      h.classList.toggle('d-none', !groupVisible);
    });

    // process External
    document.querySelectorAll('.externalTable .group-header').forEach(h=>{
      const date = h.dataset.date;
      let groupVisible = false;
      document.querySelectorAll(`.externalTable .group-${date}`).forEach(r=>{
        const okDate = (!from || r.dataset.date>=from)
                    && (!to   || r.dataset.date<=to);
        const okRec  = test(r,'recipe', rf);
        const okCat  = test(r,'category', cf, true);
        const okDep  = test(r,'department', df, true);
        const show   = okDate && okRec && okCat && okDep;
        r.classList.toggle('d-none', !show);
        if(show) {
          groupVisible = true;
          retSum    += +r.dataset.returns||0;
          extQtySum += +r.dataset.qty    ||0;
          extSum    += +r.dataset.total  ||0;
        }
      });
      h.classList.toggle('d-none', !groupVisible);
    });

    // update summaries
    const grand = showSum + extSum;
    sumShowEl.textContent = showSum.toFixed(2);
    pctShowEl.textContent = grand? Math.round(showSum*100/grand)+'%' : '0%';
    sumExtEl .textContent = extSum.toFixed(2);
    pctExtEl .textContent = grand? Math.round(extSum*100/grand)+'%' : '0%';

    // update footers
    qtyShowEl.textContent   = qtySum;
    soldShowEl.textContent  = soldSum;
    reuseShowEl.textContent = reuseSum;
    wasteShowEl.textContent = wasteSum;
    footerShowEl.textContent= showSum.toFixed(2);

    retExtEl .textContent   = retSum;
    qtyExtEl .textContent   = extQtySum;
    footerExtEl.textContent = extSum.toFixed(2);
  }

  // wire up
  [fromIn,toIn,recIn,catIn,deptIn].forEach(el=>{
    el.addEventListener('input',applyFilter);
    el.addEventListener('change',applyFilter);
  });

  applyFilter();

  // group toggle
  document.querySelectorAll('.toggle-arrow').forEach(btn=>{
    btn.addEventListener('click', ()=>{
      const tr   = btn.closest('tr');
      const date = tr.dataset.date;
      const icon = btn.querySelector('i');
      document.querySelectorAll(`.group-${date}`).forEach(r=>{
        r.classList.toggle('d-none');
      });
      icon.classList.toggle('bi-caret-right-fill');
      icon.classList.toggle('bi-caret-down-fill');
    });
  });
});
</script>
<?php $__env->stopSection(); ?>




<?php echo $__env->make('frontend.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Applications/XAMPP/htdocs/bakery/resources/views/frontend/records/index.blade.php ENDPATH**/ ?>